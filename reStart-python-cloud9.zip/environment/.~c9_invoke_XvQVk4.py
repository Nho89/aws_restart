userReply = input("Do you need to ship a package? (Enter yes or no) ")

if userReply == "yes":
    print("")